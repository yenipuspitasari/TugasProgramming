import PostList from "./components/PostList";

function App()  {
  return (
    <main>
      {/* <Post author="Bejo" body="Belajar React.js tidak sulit" />
      <Post author="Banget" body="Kuliah di Informatika UPGRIS is Awesome!" /> */}
      <PostList /> 
    </main>
  )
}

export default App;
